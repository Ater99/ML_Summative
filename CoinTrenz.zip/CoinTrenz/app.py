from flask import Flask, render_template, request
import pandas as pd
import joblib  # If using scikit-learn for model loading
import matplotlib.pyplot as plt
import numpy as np

app = Flask(__name__)

# Placeholder function to simulate model prediction based on user input


# Define a function to load the model and predict the prices
def predict_prices(prediction_days, start_date, end_date):
    # Load your trained model
    model = joblib.load('models/cointrenz.pkl')

    # Convert the start date and end date to numeric values
    start_date = pd.to_datetime(start_date).toordinal()
    end_date = pd.to_datetime(end_date).toordinal()

    # Create a numpy array of the features
    X = np.array([[start_date, end_date]])

    # Use the model to predict the prices for each day
    predicted_prices = model.predict(X)

    # Return the predicted prices as a list
    return predicted_prices.tolist()


# Define a function to plot the results based on user input
def plot_results(actual_prices, predicted_prices, start_date, end_date):
    import matplotlib.pyplot as plt
    import pandas as pd

    # Reindex the dataframe or create an index based on the date range
    date_range = pd.date_range(start=start_date, end=end_date)
    x = pd.Series(date_range)
    labels = x.dt.strftime('%Y-%m-%d')  # Format the date labels

    # Plot the actual and predicted prices
    plt.figure(figsize=(25, 15), dpi=80, facecolor='w', edgecolor='k')
    ax = plt.gca()
    plt.plot(actual_prices, color='red', label="Real BTC Price")
    plt.plot(predicted_prices[:len(actual_prices)],
             color='blue', label="Predicted BTC Price")
    plt.title("BTC Price Prediction", fontsize=40)

    # Set xticks based on the date range
    plt.xticks(range(len(labels)), labels, rotation='vertical')

    # Set fontsize for 'x' and 'y' ticks
    for tick in ax.xaxis.get_major_ticks():
        tick.label1.set_fontsize(18)
    for tick in ax.yaxis.get_major_ticks():
        tick.label1.set_fontsize(18)

    # Set plot labels and legend
    plt.xlabel('Time', fontsize=40)
    plt.ylabel('BTC Price(USD)', fontsize=40)
    plt.legend(loc=2, prop={'size': 25})

    # Save the plot as a PNG file
    plt.savefig('static/plot.png')

# Define a route for the prediction page


@app.route("/predict")
def predict():
    # Get the user input for the number of days to predict
    prediction_days = request.args.get("days", default=10, type=int)

    # Get the user input for the starting date
    start_date = request.args.get("start_date", default="2021-01-01")

    # Get the user input for the ending date
    end_date = request.args.get("end_date", default="2021-01-10")

    # Predict the prices using the user input
    predicted_prices = predict_prices(prediction_days, start_date, end_date)

    # Assuming 'actual_prices' and 'predicted_prices' are obtained from model predictions
    # Replace these placeholders with your actual data
    actual_prices = [100, 110, 105]  # Replace with actual BTC prices

    # Plot the results using the user input and the predicted prices
    plot_results(actual_prices, predicted_prices, start_date, end_date)

    # Render the predict.html template and pass the predicted prices and the plot image as variables
    return render_template("predict.html", prices=predicted_prices, image="plot.png")


if __name__ == '__main__':
    app.run(debug=True)
